DROP TABLE IF EXISTS `#__options_`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_options.%');