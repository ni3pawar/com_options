<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Options
 * @author     nitin <niteen.pawar1989@gmail.com>
 * @copyright  2020 nitin
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;

HTMLHelper::_('behavior.keepalive');
HTMLHelper::_('behavior.tooltip');
HTMLHelper::_('behavior.formvalidation');
HTMLHelper::_('formbehavior.chosen', 'select');

// Load admin language file
$lang = Factory::getLanguage();
$lang->load('com_options', JPATH_SITE);
$doc = Factory::getDocument();
$doc->addScript(Uri::base() . '/media/com_options/js/form.js');

$user    = Factory::getUser();
$canEdit = OptionsHelpersOptions::canUserEdit($this->item, $user);


?>

<div class="option-edit front-end-edit">
	<?php if (!$canEdit) : ?>
		<h3>
			<?php throw new Exception(Text::_('COM_OPTIONS_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
		</h3>
	<?php else : ?>
		<?php if (!empty($this->item->id)): ?>
			<h1><?php echo Text::sprintf('COM_OPTIONS_EDIT_ITEM_TITLE', $this->item->id); ?></h1>
		<?php else: ?>
			<h1><?php echo Text::_('COM_OPTIONS_ADD_ITEM_TITLE'); ?></h1>
		<?php endif; ?>

		<form id="form-option"
			  action="<?php echo Route::_('index.php?option=com_options&task=option.save'); ?>"
			  method="post" class="form-validate form-horizontal" enctype="multipart/form-data">
			
	<input type="hidden" name="jform[id]" value="<?php echo $this->item->id; ?>" />

	<input type="hidden" name="jform[ordering]" value="<?php echo $this->item->ordering; ?>" />

	<input type="hidden" name="jform[state]" value="<?php echo $this->item->state; ?>" />

	<input type="hidden" name="jform[checked_out]" value="<?php echo $this->item->checked_out; ?>" />

	<input type="hidden" name="jform[checked_out_time]" value="<?php echo $this->item->checked_out_time; ?>" />

				<?php echo $this->form->getInput('created_by'); ?>
				<?php echo $this->form->getInput('modified_by'); ?>
	<input type="hidden" name="jform[type]" value="<?php echo $this->item->type; ?>" />

	<input type="hidden" name="jform[name]" value="<?php echo $this->item->name; ?>" />

	<input type="hidden" name="jform[cost]" value="<?php echo $this->item->cost; ?>" />

	<input type="hidden" name="jform[option_hours]" value="<?php echo $this->item->option_hours; ?>" />

	<input type="hidden" name="jform[weight]" value="<?php echo $this->item->weight; ?>" />

	<input type="hidden" name="jform[shopping_site_content]" value="<?php echo $this->item->shopping_site_content; ?>" />

	<input type="hidden" name="jform[tech_talk]" value="<?php echo $this->item->tech_talk; ?>" />

			<div class="control-group">
				<div class="controls">

					<?php if ($this->canSave): ?>
						<button type="submit" class="validate btn btn-primary">
							<?php echo Text::_('JSUBMIT'); ?>
						</button>
					<?php endif; ?>
					<a class="btn"
					   href="<?php echo Route::_('index.php?option=com_options&task=optionform.cancel'); ?>"
					   title="<?php echo Text::_('JCANCEL'); ?>">
						<?php echo Text::_('JCANCEL'); ?>
					</a>
				</div>
			</div>

			<input type="hidden" name="option" value="com_options"/>
			<input type="hidden" name="task"
				   value="optionform.save"/>
			<?php echo HTMLHelper::_('form.token'); ?>
		</form>
	<?php endif; ?>
</div>
